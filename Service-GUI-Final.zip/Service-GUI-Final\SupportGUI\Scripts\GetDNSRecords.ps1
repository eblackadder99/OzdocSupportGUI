$results = Get-DnsServerZone | ForEach-Object {
    $zone = $_.zonename
    Get-DnsServerResourceRecord $zone | Select-Object @{n='ZoneName';e={$zone}}, HostName, timestamp, RecordType, @{n='RecordData';e={if ($_.RecordData.IPv4Address.IPAddressToString) {$_.RecordData.IPv4Address.IPAddressToString} else {$_.RecordData.NameServer.ToUpper()}}}
}

$results | Export-Csv -NoTypeInformation C:\users\%user%\desktop\$websiteDNSRecords.csv -Append