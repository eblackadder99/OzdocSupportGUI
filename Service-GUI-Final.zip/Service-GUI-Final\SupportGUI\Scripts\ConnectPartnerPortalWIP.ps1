# Connect to MSOnline
Connect-MsolService

# Prompt for client to connect to
$client = Read-Host -Prompt = "What tenant are you connecting to?"

# Match client to correct tenant
$tenant = Get-MsolPartnerContract | Where-Object{$_.Name -match "$client"}

# Get tenant ID
$tenantID = $tenant.tenantID

