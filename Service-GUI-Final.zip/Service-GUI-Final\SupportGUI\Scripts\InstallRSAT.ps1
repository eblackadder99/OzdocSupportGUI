# Sets Powershell execution policy to allow remote signed modules
Set-ExecutionPolicy RemoteSigned

# Installs the RSAT Module
Get-WindowsCapability -Name RSAT* -Online | Add-WindowsCapability -Online

# Sets Powershell execution policy back to Windows default
Set-ExecutionPolicy AllSigned