# Resets all network adaptors
Restart-NetAdapter