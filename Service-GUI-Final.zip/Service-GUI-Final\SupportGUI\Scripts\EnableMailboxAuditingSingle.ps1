$ScriptBlock = {Get-Mailbox -ResultSize Unlimited | Set-Mailbox -AuditEnabled $true -AuditOwner MailboxLogin, HardDelete, SoftDelete, Update, Move -AuditDelegate SendOnBehalf, MoveToDeletedItems, Move -AuditAdmin Copy, MessageBind}
 
# Establish a PowerShell session with Office 365. You'll be prompted for your Delegated Admin credentials
$UserName = Read-Host -Prompt "Enter Email Address (Credentials are only saved in this session)"
$Cred = Get-Credential -Credential AZUREAD\$Username

# Connect to MSOnline
Connect-MsolService -Credential $Cred

# Finds customer tenant
# Can be optimised by packaging the function in a profile
$name = Read-Host "Type part of the organisations name"
$Customers = @()
$Customers = @(Get-MsolPartnerContract | Where-Object {$_.Name -match $name})
 
    if($Customers.Count -gt 1){
 
        Write-Host "More than 1 customer found, rerun the function:"
        Write-Host " "
 
        ForEach($Customer in $Customers){
 
            Write-Host $Customer.Name
        }
    }
 
    if($Customers.count -eq 0){
     
        Write-Host "No customers found, rerun the function"
    }
 
    if($Customers.Count -eq 1){
 
    $global:cid = $Customers.tenantid
     
    Write-Host "$($Customers.name) selected. User the -tenantid `$cid parameter to run MSOL commands for this customer."
    }
 
# Enables mailbox auditing for specified customer
# This can be optimised as it is from the enable all script
foreach ($customer in $customers) { 
 
    $InitialDomain = Get-MsolDomain -TenantId $customer.TenantId | Where-Object {$_.IsInitial -eq $true}
    Write-Host "Enabling Mailbox Auditing for $($Customer.Name)"
    $DelegatedOrgURL = "https://ps.outlook.com/powershell-liveid?DelegatedOrg=" + $InitialDomain.Name
    Invoke-Command -ConnectionUri $DelegatedOrgURL -Credential $Cred -Authentication Basic -ConfigurationName Microsoft.Exchange -AllowRedirection -ScriptBlock $ScriptBlock -HideComputerName
}